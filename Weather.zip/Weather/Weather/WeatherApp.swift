//
//  WeatherApp.swift
//  Weather
//
//  Created by user238402 on 4/9/23.
//

import SwiftUI

@main
struct WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
