//
//  WeatherButton.swift
//  Weather
//
//  Created by Chuy Seinen on 4/10/23.
//

import SwiftUI

struct WeatherButton: View {
    var title: String
    @Binding var isNight: Bool
    //var backgroundColor: Color
    //var textColor: Color
    
    var body: some View {
        Text(title)
            .frame(width: 280, height: 50)
            .background(isNight ? .black: .white)
            .foregroundColor(isNight ? .white: .blue)
            .font(.system(size: 20,weight: .bold, design: .default))
            .cornerRadius(10)
    }
}
